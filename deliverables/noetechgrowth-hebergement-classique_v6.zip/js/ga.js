// Google Analytics 4 avec le mode Consentement : aucun cookie tant que le visiteur n'a pas accepté.
// Fichier externe (et non script inline) pour rester compatible avec la Content-Security-Policy.
(function () {
  var ID = 'G-0XWL8P9TS2';
  var KEY = 'ntg-consent';
  window.dataLayer = window.dataLayer || [];
  function gtag() { window.dataLayer.push(arguments); }
  window.gtag = gtag;

  var saved = null;
  try { saved = localStorage.getItem(KEY); } catch (e) {}

  gtag('consent', 'default', {
    ad_storage: 'denied',
    ad_user_data: 'denied',
    ad_personalization: 'denied',
    analytics_storage: saved === 'granted' ? 'granted' : 'denied'
  });
  gtag('js', new Date());
  gtag('config', ID);

  // Les éléments marqués data-track (CTA, WhatsApp, e-mail, copie de modèle…) deviennent des événements GA4.
  document.addEventListener('click', function (e) {
    var el = e.target && e.target.closest ? e.target.closest('[data-track]') : null;
    if (!el) return;
    gtag('event', el.getAttribute('data-track'), {
      source: el.getAttribute('data-src') || undefined,
      link_url: el.href || undefined
    });
  }, true);

  var en = (document.documentElement.lang || 'fr').indexOf('en') === 0;
  var TXT = en
    ? { msg: 'We use Google Analytics to measure visits, only if you agree.', more: 'Privacy policy', href: '/en/privacy/', yes: 'Accept', no: 'Decline', label: 'Cookie consent' }
    : { msg: 'Nous utilisons Google Analytics pour mesurer les visites, seulement avec votre accord.', more: 'Confidentialité', href: '/confidentialite/', yes: 'Accepter', no: 'Refuser', label: 'Consentement aux cookies' };

  function choose(v) {
    try { localStorage.setItem(KEY, v); } catch (e) {}
    gtag('consent', 'update', { analytics_storage: v });
    var b = document.getElementById('ntg-consent');
    if (b) b.remove();
  }

  function banner() {
    if (document.getElementById('ntg-consent')) return;
    var box = document.createElement('div');
    box.id = 'ntg-consent';
    box.setAttribute('role', 'region');
    box.setAttribute('aria-label', TXT.label);
    var p = document.createElement('p');
    p.textContent = TXT.msg + ' ';
    var a = document.createElement('a');
    a.href = TXT.href;
    a.textContent = TXT.more;
    p.appendChild(a);
    var row = document.createElement('div');
    row.className = 'ntg-consent-btns';
    [[TXT.no, 'denied', 'ghost'], [TXT.yes, 'granted', '']].forEach(function (b) {
      var btn = document.createElement('button');
      btn.type = 'button';
      btn.textContent = b[0];
      if (b[2]) btn.className = b[2];
      btn.addEventListener('click', function () { choose(b[1]); });
      row.appendChild(btn);
    });
    box.appendChild(p);
    box.appendChild(row);
    document.body.appendChild(box);
  }

  function init() {
    if (saved !== 'granted' && saved !== 'denied') banner();
    document.addEventListener('click', function (e) {
      if (e.target && e.target.closest && e.target.closest('[data-consent-reset]')) {
        try { localStorage.removeItem(KEY); } catch (err) {}
        banner();
      }
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
