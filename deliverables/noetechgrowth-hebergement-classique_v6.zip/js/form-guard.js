// Les calculateurs et le test fonctionnent sans envoi : on bloque la soumission (remplace onsubmit="return false", compatible CSP).
document.addEventListener('submit', function (e) {
  if (e.target instanceof HTMLFormElement && e.target.hasAttribute('data-nosubmit')) e.preventDefault();
});
